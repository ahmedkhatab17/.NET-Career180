﻿using System;
using System.Collections;

class Program
{

    static void Main()
    {
        int x = 10;
        int y = x; // y is a copy of x

        y = 20;     // Changing y does not affect x
        Console.WriteLine(x);  // Outputs: 10
        Console.WriteLine(y);  // Outputs: 20

        Console.WriteLine("-------------------------------");

        Person p1 = new Person();
        p1.Name = "John";

        Person p2 = p1;  // p2 refers to the same Person object as p1
        p2.Name = "Ahmed";  // Modifies the same object that p1 refers to

        Console.WriteLine(p1.Name);  // Outputs: Ahmed
        Console.WriteLine(p2.Name);  // Outputs: Ahmed

        Console.WriteLine("-------------------------------");

        int a = 5;
        Console.WriteLine("Before method call: " + a);  // Outputs: 5

        ModifyValue(a);  // Passing by value
        Console.WriteLine("After method call: " + a);   // Outputs: 5 (no change)

        Console.WriteLine("-------------------------------");

        Person p = new Person() { Name = "Alice" };
        Console.WriteLine("Before method: " + p.Name); // Output: Alice

        ModifyPerson(p);
        Console.WriteLine("After method: " + p.Name); // Output: Bob

        Console.WriteLine("-------------------------------");

        int b = 5;
        Console.WriteLine("Before method call: " + b);  // Outputs: 5

        ModifyValueByRef(ref b);  // Passing by reference
        Console.WriteLine("After method call: " + b);   // Outputs: 10 (value changed)

        Console.WriteLine("-------------------------------");

        int result;
        AddNumbers(10, 20, out result);  // Using 'out'
        Console.WriteLine("The result is: " + result);  // Outputs: The result is: 30

        Console.WriteLine("-------------------------------");

        int num = 10;
        DisplayValue(in num);
        Console.WriteLine(num);  // Output: 10 (unchanged)

        Console.WriteLine("--------------Implicit-----------------");


        int intValue = 123;
        double doubleValue = intValue;  // Implicit conversion: int to double

        Console.WriteLine(doubleValue);  // Outputs: 123

        char cha = 'a';
        int intV = cha;
        Console.WriteLine(intV); // Outputs: 97 ASCII Code of 'a'

        Dog dog = new Dog();
        Animal animal = dog;  // Implicit conversion from Dog to Animal
        Console.WriteLine(animal.GetType().Name);  // Outputs: Dog

        Console.WriteLine("--------------Explicit-----------------");

        int intValuee1 = 50;
        int intValuee2 = 47;
        int sum = intValuee1 + intValuee2; // 97

        char c = (char)sum; // CAST
        Console.WriteLine(c);

        double pi = 3.14159;
        int piInt = (int)pi; // Explicit conversion: double to int (data loss)
        Console.WriteLine(piInt);  // Outputs: 3 (decimal part is truncated)

        Animal animal2 = new Dog();  // Implicit conversion from Dog to Animal
        Dog dog2 = (Dog)animal2;  // Explicit cast from Animal to Dog

        Console.WriteLine(dog2.GetType().Name);  // Outputs: Dog

        Console.WriteLine("---------------Array----------------");

        int[] numbers = new int[100000000];  // Create an array of integers with 5 elements
        numbers[0] = 10;
        numbers[1] = 20;
        numbers[2] = 30;
        numbers[3] = 40;
        numbers[4] = 50;


        Console.WriteLine(numbers[0]);  //The same time will take to get Outputs: 40
        Console.WriteLine(numbers[99999999]); //The same time will take to get Outputs: 10
        Console.WriteLine(numbers.Length);  // Outputs: 5 (length of the array)
        Console.WriteLine("------------List-------------------");


        // You tasked as sort the persons des Descending
        List<Person> ListOfPersonDB = new List<Person>();
        ListOfPersonDB.Add(new Person { Id = 8, Name = "Ahmed8" });
        ListOfPersonDB.Add(new Person { Id = 1, Name = "Ahmed1" });
        ListOfPersonDB.Add(new Person { Id = 1, Name = "Ahmed1" });
        ListOfPersonDB.Add(new Person { Id = 2, Name = "Ahmed2" });
        ListOfPersonDB.Add(new Person { Id = 5, Name = "Ahmed5" });
        ListOfPersonDB.Add(new Person { Id = 4, Name = "Ahmed4" });
        ListOfPersonDB.Add(new Person { Id = 4, Name = "Ahmed4" });
        ListOfPersonDB.Add(new Person { Id = 4, Name = "Ahmed4" });

        ListOfPersonDB = ListOfPersonDB.OrderBy(a => a.Id).ToList();

        foreach (var item in ListOfPersonDB)
        {
            Console.WriteLine("My name is:" + item.Name);
        }
        Console.WriteLine("------------List-------------------");


        List<int> list = new List<int>(); // More dynamic 
        list.Add(50);
        list.Add(10);
        list.Add(20);
        list.Add(30);
        list.Add(40);


        foreach (var item in list)
        {
            Console.WriteLine("Item is:" + item);
        }

        Console.WriteLine(list[1]);  // Outputs: 20
        Console.WriteLine(list.Count);  // Outputs: 3 (size of the list)

        Console.WriteLine("--------------Dictionary-----------------");

        // Key Is unique
        Dictionary<string, int> ages = new Dictionary<string, int>();
        ages.Add("Alice", 25);
        ages.Add("Bob", 30);
        ages.Add("Bob2", 40);

        Console.WriteLine(ages["Alice"]);  // Outputs: 25
        Console.WriteLine(ages["Bob2"]);  // Outputs: 40

        Console.WriteLine("----------------Queue-----------------");

        Queue<string> queue = new Queue<string>(); // First In First Out
        queue.Enqueue("First");  // Enqueue this add object to the end of Queue
        queue.Enqueue("Second");
        queue.Enqueue("Third");
        queue.Enqueue("Four");


        Console.WriteLine(queue.Dequeue());
        Console.WriteLine(queue.Dequeue());
        Console.WriteLine(queue.Dequeue());
        Console.WriteLine(queue.Dequeue());


        //Console.WriteLine(queue.Peek()); // Peek this return the object at the first without remove it
        //Console.WriteLine(queue.Peek()); // Peek this return the object at the first without remove it
        //Console.WriteLine(queue.Dequeue()); // Dequeue this return the object at the first with remove it
        //Console.WriteLine(queue.Peek()); // Peek this return the object at the first without remove it
        //Console.WriteLine(queue.Dequeue());
        //Console.WriteLine(queue.Peek());

        Console.WriteLine("----------------Stack-----------------");

        Stack<string> stack = new Stack<string>(); // Last In First Out
        stack.Push("First"); // Push Insert the object at the top of stack
        stack.Push("Second");
        stack.Push("Third");
        stack.Push("Four"); // This is the first object will remove

        Console.WriteLine(stack.Pop());  // Pop remove and return the object at top of Stack
        Console.WriteLine(stack.Peek()); // Peek this return the object at the first without remove it
        Console.WriteLine(stack.Pop());
        Console.WriteLine(stack.Peek());


        Console.WriteLine("----------------HashSet-----------------");

        HashSet<int> numbersHashSet = new HashSet<int>();
        numbersHashSet.Add(10);
        numbersHashSet.Add(20);
        numbersHashSet.Add(10);  // Duplicate, not added
        numbersHashSet.Add(10);  // Duplicate, not added
        numbersHashSet.Add(10);  // Duplicate, not added
        numbersHashSet.Add(10);  // Duplicate, not added
        numbersHashSet.Add(10);  // Duplicate, not added
        numbersHashSet.Add(10);  // Duplicate, not added

        Console.WriteLine(numbersHashSet.Count);  // Outputs: 2 (only unique elements are stored)

        HashSet<Person> Persons = new HashSet<Person>();
        Persons.Add(new Person { Id = 8, Name = "Ahmed8" });
        Persons.Add(new Person { Id = 1, Name = "Ahmed1" });
        Persons.Add(new Person { Id = 1, Name = "Ahmed1" });
        Persons.Add(new Person { Id = 2, Name = "Ahmed2" });
        Persons.Add(new Person { Id = 5, Name = "Ahmed5" });
        Persons.Add(new Person { Id = 4, Name = "Ahmed4" });
        Persons.Add(new Person { Id = 4, Name = "Ahmed4" });
        Persons.Add(new Person { Id = 4, Name = "Ahmed4" });

        Console.WriteLine(Persons.Count); // 8

        Console.WriteLine("----------------SortedList-----------------");

        SortedList<int, string> SortedList = new SortedList<int, string>();
        SortedList.Add(2, "Two");
        SortedList.Add(1, "One");
        SortedList.Add(3, "Three");

        foreach (var item in SortedList)
        {
            Console.WriteLine($"{item.Key}: {item.Value}");
        }

        SortedList<string, int> SortedListt = new SortedList<string, int>();
        SortedListt.Add("Two", 2); // By default order by acinding
        SortedListt.Add("One", 1);
        SortedListt.Add("Three", 3);

        foreach (var item in SortedListt.OrderBy(a => a.Key))
        {
            Console.WriteLine($"{item.Key}: {item.Value}");
        }


        Console.WriteLine("----------------IEnumerator and IEnumerable\r\n-----------------");

        MyCollection collection = new MyCollection();
        foreach (int i in collection)
        {
            Console.WriteLine($"Itertion: {i}");
        }


        List<int> numberss = new List<int> { 1, 2, 3, 4, 5 };
        IEnumerable<int> query = numberss.Where(n => n > 3);  // query is executed immediately when enumerated
        foreach (var n in query)
        {
            Console.WriteLine(n); // executes immediately and retrieves data in-memory
        }

        //IQueryable queryable = DBNull.invoices.where(a => a.customerId = CustoId);

        //queryable = queryable.where(a => a.Date == Date);

        //IEnumerable<int> dbList = dbContext.Numbers.Where(n => n > 3);

        //// select * from Numbers where customerId = CustoId;
        //IQueryable<int> queryy = dbContext.Numbers.Where(n => n > 3);  // query is not executed until you enumerate



        //var rr = queryable.totlist();

        //var resultt = query.AsQueryable(); // The SQL query is sent to the database here
        //foreach (var nu in query)
        //{
        //    Console.WriteLine(num); // query is executed on the database at this point, not in-memory
        //}


    }


    class Animal { }
    class Dog : Animal { }


    static void DisplayValue(in int number)
    {
        Console.WriteLine(number);  // Output: 10
        //number = 20; // Error: Cannot modify an 'in' parameter
    }

    static void AddNumbers(int a, int b, out int sum)
    {
        sum = a + b;  // Must assign a value to the 'out' parameter
    }

    static void ModifyValueByRef(ref int x)
    {
        x = 10;  // Modifies the original variable
    }

    static void ModifyPerson(Person person)
    {
        person.Name = "Bob"; // This changes the name of the object

        person = new Person() { Name = "Charlie" }; // This changes the reference, but does not affect the original

        Console.WriteLine("Inside method: " + person.Name);
    }

    static void ModifyValue(int x)
    {
        x = 100000;  // Modifying the copy
    }

    class Person
    {
        public int Id;
        public string Name;
    }


    public class MyCollection : IEnumerable
    {
        private int[] numbers = { 1, 2, 3, 4, 5 };
         
        IEnumerator IEnumerable.GetEnumerator()
        {
            throw new NotImplementedException();
        }
    }
    public class MyEnumerator : IEnumerator
    {
        private int[] numbers;
        private int position = -1;
        public MyEnumerator(int[] numbers)
        {
            this.numbers = numbers;
        }
        public bool MoveNext()
        {
            position++;
            return position < numbers.Length;
        }
        public void Reset()
        {
            position = -1;
        }
        public object Current => numbers[position];
    }


}
